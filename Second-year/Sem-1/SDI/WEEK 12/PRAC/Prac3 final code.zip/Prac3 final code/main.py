# Author: Wolfgang Mayer, University of South Australia, 2021
# License: CC BY https://creativecommons.org/licenses/by/4.0/

from datetime import datetime
from accessor import InMemoryCalendarAccessor
from manager import CalendarManager


def createDummyMeetings(manager):
    manager.createMeeting("First Meeting", datetime(2021,5,17,9,10), ["Wolfgang"])
    manager.createMeeting("Second Meeting", datetime(2021,5,17,11,10), ["Wolfgang","Mei","Matt"])
    manager.createMeeting("Third Meeting", datetime(2021,5,17,14,10), ["Matt"])


def checkFindMeeting(manager):
    nextMeetingInfo = manager.findEarliestMeetingIncludingAttendee("Matt")
    print("The next meeting with Matt is:")
    print(nextMeetingInfo)


def main():
    accessor = InMemoryCalendarAccessor()
    manager = CalendarManager(accessor)
    createDummyMeetings(manager)
    checkFindMeeting(manager)


if __name__ == "__main__":
    main()
