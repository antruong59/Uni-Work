# Author: Wolfgang Mayer, University of South Australia, 2021
# License: CC BY https://creativecommons.org/licenses/by/4.0/

class CalendarManager:
    """The CalendarManager orchestrates the use cases related to interacting with the calendar.
    Currently only creating meetings and finding the earliest meeting for an attendee are implemented."""

    # TODO implement the remaining use cases

    def __init__(self, calendarAccessor):
        self.calendar = calendarAccessor

    def createMeeting(self, description, startTime, attendeeNames):
        meetingId = self.calendar.createMeeting(description, startTime, attendeeNames)
        return meetingId

    def findEarliestMeetingIncludingAttendee(self, name):
        meetingInfo = self.calendar.findEarliestMeetingIncludingAttendee(name)
        return meetingInfo
