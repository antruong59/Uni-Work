# Author: Wolfgang Mayer, University of South Australia, 2021
# License: CC BY https://creativecommons.org/licenses/by/4.0/

from datetime import datetime
from unittest.mock import Mock
import pytest

from accessor import InMemoryCalendarAccessor, MeetingInfo
from manager import CalendarManager


@pytest.fixture
def manager():
    accessor = InMemoryCalendarAccessor()
    return CalendarManager(accessor)


@pytest.fixture
def scenario1MeetingsManager(manager):
    manager.createMeeting("First Meeting", datetime(2021,5,17,9,10), ["Wolfgang"])
    manager.createMeeting("Second Meeting", datetime(2021,5,17,11,10), ["Wolfgang","Mei","Matt"])
    manager.createMeeting("Third Meeting", datetime(2021,5,17,14,10), ["Matt"])
    return manager


def testFindEarliestMeeting(scenario1MeetingsManager):
    # run some code
    meeting = scenario1MeetingsManager.findEarliestMeetingIncludingAttendee("Matt")
    # check that the correct meeting is returned
    assert meeting.description == "Second Meeting"


def testMeetingMustHaveAttendees(manager):
    with pytest.raises(ValueError):
        manager.createMeeting("Meeting nobody attends", datetime(2021,5,17,1,0), [])


@pytest.fixture
def scenario2MeetingsManager(manager):
    """create some meetings"""
    manager.createMeeting("Morning Meeting", datetime(2021,5,24,9,10), ["Alice"])
    manager.createMeeting("Afternoon Meeting", datetime(2021,5,24,15,0), ["Bob","Charlie"])
    manager.createMeeting("Lunch Meeting", datetime(2021,5,24,12,0), ["Alice","Bob","Charlie"])
    return manager


def testFindEarliestMeetingReordered(scenario2MeetingsManager):
    meeting = scenario2MeetingsManager.findEarliestMeetingIncludingAttendee("Bob")
    assert meeting.description == "Lunch Meeting"


def testMgrFindEarliestMeetingCallsAccessor():
    accessor = Mock()
    manager = CalendarManager(accessor)
    manager.findEarliestMeetingIncludingAttendee("Alice")
    assert accessor.findEarliestMeetingIncludingAttendee.called_once_with("Alice")


def testMgrFindEarliestMeetingResult():
    expected = MeetingInfo("Nonexistant meeting", datetime(2021, 5, 24, 7, 0), ["Alice"])
    accessor = Mock()
    accessor.findEarliestMeetingIncludingAttendee.return_value = expected
    manager = CalendarManager(accessor)
    meeting = manager.findEarliestMeetingIncludingAttendee("Alice")
    assert meeting == expected
