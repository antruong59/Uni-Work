# Overview

This project implements a simple calendar application that maintains a searchable calendar containing meetings. Meetings are associated with attendees.

## Requirements

Requires python >=3.6 and pytest

## Run

To run, execute `python main.py` or run the `pytest` tests

## Architecture

The architecture uses layers to separate

* Client application
* Business logic
* Resource Abstractions and Data Stores.

## Limitations

* Currently, the data store is in memory.

* The only calendar functions that are currently implemented are:

  * create a meeting, and
  * find the next meeting that includes a given attendee.
