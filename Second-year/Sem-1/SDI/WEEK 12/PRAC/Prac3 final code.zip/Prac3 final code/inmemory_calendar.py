# Author: Wolfgang Mayer, University of South Australia, 2021
# License: CC BY https://creativecommons.org/licenses/by/4.0/

class InMemoryCalendar:
    """This calendar implementation stores meeting as objects in memory.
       The list of Meeting objects, self.meetings, must be maintained in
       sorted order by meeting start time, since findEarliestMeetingIncludingAttendee depends
       on this order."""

    def __init__(self):
        self.meetings = []

    def createMeeting(self, description, startTime, attendeeNames):
        meeting = Meeting(description, startTime, attendeeNames)
        self.addMeeting(meeting)
        return meeting

    def addMeeting(self, meeting):
        self.meetings.append(meeting)
        # sort the meetings, since findEarliestMeetingIncludingAttendee depends on it
        self.meetings.sort(key=lambda meeting: meeting.getStartTime())

    def findEarliestMeetingIncludingAttendee(self, name):
        meeting = self.findMeeting(lambda m: m.includesAttendeeNamed(name))
        return meeting

    def findMeeting(self, predicate):
        for meeting in self.meetings:
            if predicate(meeting):
                return meeting
        return None


class UniqueIdGenerator:

    def __init__(self):
        self.prevId = 0

    def next(self):
        self.prevId += 1
        return self.prevId


class Meeting:

    idGenerator = UniqueIdGenerator()

    def __init__(self, description, startTime, attendeeNames):
        if not attendeeNames:
            raise ValueError("Meeting must have one or more attendees")
        self.id = self.idGenerator.next()
        self.description = description
        self.attendees = [self._createAttendee(name) for name in attendeeNames]
        self.startTime = startTime

    def _createAttendee(self, name):
        return Contact(name)

    def getId(self):
        return self.id

    def getDescription(self):
        return self.description

    def getStartTime(self):
        return self.startTime

    def includesAttendeeNamed(self, name):
        for contact in self.attendees:
            if contact.getName() == name:
                return True
        return False

    def __repr__(self):
        attendeeNames = ",".join(map(str, self.attendees))
        return f"Meeting {self.id} description: {self.description} starting: {self.startTime} attendees: {attendeeNames}"


class Contact:

    def __init__(self, name):
        self.name = name

    def getName(self):
        return self.name

    def __repr__(self):
        return self.name
