# Author: Wolfgang Mayer, University of South Australia, 2021
# License: CC BY https://creativecommons.org/licenses/by/4.0/

from dataclasses import dataclass
from datetime import datetime

from inmemory_calendar import InMemoryCalendar


# TODO Create ab abstract base class for the public interface
class InMemoryCalendarAccessor:
    """This class, together with the MeetingInfo data class,
       represent the public interface of the In-Memory Calendar implementation.
       All operations on the in memory calendar store must go through this façade."""

    def __init__(self):
        self.calendar = InMemoryCalendar()

    def createMeeting(self, description, startTime, attendeeNames):
        meeting = self.calendar.createMeeting(description, startTime, attendeeNames)
        return meeting.getId()

    def findEarliestMeetingIncludingAttendee(self, name):
        meeting = self.calendar.findEarliestMeetingIncludingAttendee(name)
        # return meeting
        return self._getMeetingInfo(meeting) if meeting is not None else None

    def _getMeetingInfo(self, meeting):
        meetingInfo = MeetingInfo(meeting.getId(), meeting.getDescription(), meeting.getStartTime())
        return meetingInfo


@dataclass
class MeetingInfo:
    """This class represents the meeting information independent of the backend store implementation."""

    id: int
    description: str
    startTime: datetime

    def __repr__(self):
        return f"Meeting {self.id} \"{self.description}\" at {self.startTime}"
